# -*- coding: utf-8 -*-
from setuptools import setup, Command
from setuptools.command.install import install as _install
from setuptools.command.develop import develop as _develop
from distutils.command.build import build as _build
import subprocess
import shutil
import os
import re
import sys
import platform

IS_WINDOWS = platform.system() == 'Windows'
IS_MAC = platform.system() == 'Darwin'

if sys.version_info < (3, 5):
    sys.exit("Python version must be >= 3.5")


def read(*paths):
    this_dir = os.path.dirname(os.path.realpath(__file__))
    content = open(os.path.join(this_dir, *paths), "rb").read()
    return content.decode("utf-8")


version = re.search("__version__ = '(.+)'", read('funq_server/__init__.py')).group(1)


class build_libfunq(Command):
    """
    Construction de la lib c++ (cross-platform: Ninja + MSVC on Windows).
    """
    user_options = [
        ('build-lib=', 'd', "directory to \"build\" (copy) to"),
        ('force', 'f', "forcibly build everything (ignore file timestamps)"),
        ('cmake-path=', None, "path to the cmake executable"),
        ('make-path=', None, "path to the make/ninja executable"),
        ('generator=', None, "cmake generator, e.g. 'Ninja'"),
        ('qt5-dir=', None, "path to Qt5 cmake dir (containing Qt5Config.cmake)"),
        ('debug', 'g', "compile/link with debugging information"),
        ('inplace', 'i', "ignore build-lib and put compiled extensions into the source directory"),
    ]

    boolean_options = ['inplace', 'debug', 'force']

    def initialize_options(self):
        self.build_lib = None
        self.force = None
        self.inplace = None
        self.debug = None
        self.cmake_path = None
        self.make_path = None
        self.generator = None
        self.qt5_dir = None

        if IS_WINDOWS:
            self.funqlib_name = 'Funq.dll'
        elif IS_MAC:
            self.funqlib_name = 'libFunq.dylib'
        else:
            self.funqlib_name = 'libFunq.so'

    def finalize_options(self):
        self.set_undefined_options('build',
                                   ('force', 'force'),
                                   ('debug', 'debug'),
                                   ('build_lib', 'build_lib'))

        # 默认值 + 环境变量覆盖
        if self.cmake_path is None:
            self.cmake_path = os.environ.get('FUNQ_CMAKE_PATH') or 'cmake'
        if self.make_path is None:
            self.make_path = os.environ.get('FUNQ_MAKE_PATH') or (
                'ninja' if IS_WINDOWS else 'make')
        if self.generator is None:
            self.generator = os.environ.get('FUNQ_CMAKE_GENERATOR') or (
                'Ninja' if IS_WINDOWS else None)
        if self.qt5_dir is None:
            self.qt5_dir = os.environ.get('FUNQ_QT5_DIR')

    def funqlib_out_path(self):
        base = '.' if self.inplace else self.build_lib
        return os.path.join(base, 'funq_server', self.funqlib_name)

    def run(self):
        build_dir = 'build'

        if self.force and os.path.isdir(build_dir):
            shutil.rmtree(build_dir, ignore_errors=True)

        buildtype = 'Debug' if self.debug else 'Release'
        cmake_cmd = [
            self.cmake_path,
            '-S', '.',
            '-B', build_dir,
            '-DCMAKE_BUILD_TYPE={}'.format(buildtype),
        ]
        if self.generator:
            cmake_cmd += ['-G', self.generator]
        if self.qt5_dir:
            cmake_cmd += [
                '-DQt5_DIR={}'.format(self.qt5_dir),
                '-DQt_DIR={}'.format(self.qt5_dir),
            ]
        print('running %s' % ' '.join(cmake_cmd))
        subprocess.check_call(cmake_cmd)

        # Ninja 需要在 build 目录里跑，其它生成器同理
        make_cmd = [self.make_path, '-C', build_dir]
        print('running %s' % ' '.join(make_cmd))
        subprocess.check_call(make_cmd)

        # 拷贝生成的库
        lib_dst = self.funqlib_out_path()
        lib_dir = os.path.dirname(lib_dst)
        if not os.path.isdir(lib_dir):
            os.makedirs(lib_dir)

        # 库可能落在 build/libFunq/ 下
        import glob
        build_libfunq_dir = os.path.join(build_dir, 'libFunq')
        candidates = []
        for name in (self.funqlib_name, 'Funq.dll', 'libFunq.dll',
                     'Funq.so', 'libFunq.so', 'libFunq.dylib', 'Funq.dylib'):
            candidates.append(os.path.join(build_libfunq_dir, name))
            candidates.append(os.path.join('libFunq', name))

        for src in candidates:
            if os.path.exists(src):
                shutil.copy2(src, lib_dst)
                print('copied %s -> %s' % (src, lib_dst))
                return

        # 兜底：直接在 build 目录里扫共享库
        patterns = ['*.dll', '*.so', '*.dylib']
        for pat in patterns:
            for src in glob.glob(os.path.join(build_libfunq_dir, pat)):
                # 排除像 Qt5Core.dll 这种依赖库
                base = os.path.basename(src).lower()
                if 'funq' in base:
                    shutil.copy2(src, lib_dst)
                    print('copied %s -> %s' % (src, lib_dst))
                    return

        raise RuntimeError(
            'libFunq not found in %s' % build_libfunq_dir)

    def get_outputs(self):
        return [self.funqlib_out_path()]

class build(_build):
    sub_commands = _build.sub_commands + [('build_libfunq', None)]


class install(_install):
    def run(self):
        self.run_command('build_libfunq')
        _install.run(self)


class develop(_develop):
    def run(self):
        self.reinitialize_command('build_libfunq', inplace=1)
        self.run_command('build_libfunq')
        _develop.run(self)


setup(
    name='funq-server',
    author="Julien Pagès",
    author_email="j.parkouss@gmail.com",
    url="https://github.com/parkouss/funq",
    description="write FUNctional tests for Qt applications (server)",
    long_description=read("README"),
    version=version,
    packages=['funq_server'],
    entry_points={
        'console_scripts': [
            'funq = funq_server.runner:main'
        ]
    },
    cmdclass={
        'build_libfunq': build_libfunq,
        'build': build,
        'install': install,
        'develop': develop,
    },
    install_requires=[],
    license='CeCILL v1.2',
)
