// Copyright 2015 The Crashpad Authors. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "util/win/scoped_set_event.h"

#include "base/check.h"
#include "base/logging.h"

namespace crashpad {

ScopedSetEvent::ScopedSetEvent(HANDLE event) : event_(event) {
  DCHECK(event_);
}

ScopedSetEvent::~ScopedSetEvent() {
  if (event_) {
    Set();
  }
}

bool ScopedSetEvent::Set() {
  bool rv = !!SetEvent(event_);
  if (!rv) {
    PLOG(ERROR) << "SetEvent";
  }
  event_ = nullptr;
  return rv;
}

}  // namespace crashpad
